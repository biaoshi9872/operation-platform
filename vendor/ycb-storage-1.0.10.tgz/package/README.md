## @ycb/storage

> 原生 storage 拓展，可配置过期时间，统一前缀

## 安装

```
npm install @ycb/storage --registry http://npm.ycb51.cn
```

## 使用

```
import { getLocal, setLocal, getSession, setSession, removeLocal, removeSession, clearLocal, clearSession, setBaseKey } from '@ycb/storage'

// 设置作用域
Storage.setBaseKey('TEST_')

// 普通调用
Storage.setSession('a', 0)

console.log(Storage.getSession('a')) // 0

// null 会转换成空对象
Storage.setSession('b', null)

console.log(Storage.getSession('b')) // {}

// undefined 不会转换
Storage.setSession('c', undefined)

console.log(Storage.getSession('c')) // undefined

// 添加过期时间
Storage.setSession('d', true, {
  maxAge: {
    s: 5
  }
})

Storage.setSession('e', false, {
  maxAge: {
    m: 5
  }
})


console.log(Storage.getSession('d')) // true
console.log(Storage.getSession('e')) // false
setTimeout(() => {
  console.log(Storage.getSession('d')) // undefined
  console.log(Storage.getSession('e')) // false
}, 6 * 1000);

// 添加到全局
Storage.setSession('f', 'a root string', {
  root: true
})

Storage.getSession('f', {
  root: true
}) // a root string

Storage.getSession('f') // undefined

// 清除作用域内所有 storage

clearLocal() // 清除作用域内所有 localStorage
clearSession() // 清除作用域内所有 sessionStorage

```

## 说明

### setBaseKey

为 Storage 设置一个通用前缀，最终在缓存中的真实 localStorage / sessionStorage 会加上对应前缀，防止冲突

注意：

- setBaseKey 由闭包实现修改内部变量，所以多次调用改方法时会重置 baseKey
- baseKey 只用于内部逻辑,无论是否设置 baseKey 在调用其他 API 时都无需关心 key

### 过期时间

> let { d, h, m, s } = maxAge

- d: 天数
- h: 小时
- m: 分钟
- s: 秒数

如 3 天 4 小时 5 分钟 6 秒后过期，maxAge 应为

```
{
  d: 3,
  h: 4,
  m: 5,
  s: 6
}
```

## 调试

### 打包

```
npm run build
```

### 发布

> 必需升级版本号

```
npm publish --registry http://npm.ycb51.cn
yarn publish --registry http://npm.ycb51.cn
```
