let BASE_KEY = ''
let alreadySetKey = false

interface StorageObj {
  _expiration?: number
  _data: any
}

interface AgeObj {
  d?: number
  h?: number
  m?: number
  s?: number
}

interface Options {
  root?: boolean
  maxAge?: AgeObj
}

function getStorage(key: string, target: Storage, root?: boolean): any {
  key = root ? key : BASE_KEY + key
  const item = target.getItem(key)
  // 未找到
  if (item === undefined || item === null) {
    return undefined
  }
  let itemObj: StorageObj
  try {
    itemObj = JSON.parse(item)
  } catch (error) {
    return undefined
  }
  // 非 Object 直接返回
  if (typeof itemObj !== 'object') {
    return itemObj
  }

  const { _expiration, _data } = itemObj
  // 非自定义封装 对象 直接返回
  if (!_expiration && _data === undefined) {
    return itemObj
  }
  // 未设置过期时间
  if (!_expiration || _expiration === 0) {
    return _data
  }
  // 对比过期时间 如果过期返回 undefined
  const now = new Date().getTime()
  if (now > _expiration) {
    return undefined
  }

  return _data
}

/**
 * 获取 localStorage
 * @param {String} key key
 * @param {Any} value 存储的值
 * @param {Object} maxAge 保存时间 d 天 h 时 m 分 s 秒
 */
function setStorage(key: string, value: any, maxAge: AgeObj | undefined, root: boolean | undefined, target: Storage) {
  key = root ? key : BASE_KEY + key
  // 防止 JSON.stringify 结果 'null'
  if (value === null) {
    value = {}
  }

  if (value === undefined) {
    target.removeItem(key)
    return
  }

  if (!maxAge || typeof maxAge !== 'object') {
    target.setItem(
      key,
      JSON.stringify({
        _data: value
      })
    )
    return
  }
  // 计算过期时间
  let { d, h, m, s } = maxAge
  d = d ? d * 24 * 60 * 60 * 1000 : 0
  h = h ? h * 60 * 60 * 1000 : 0
  m = m ? m * 60 * 1000 : 0
  s = s ? s * 1000 : 0

  const _expiration = +new Date() + d + h + m + s
  target.setItem(
    key,
    JSON.stringify({
      _data: value,
      _expiration
    })
  )
}

function removeStorage(key: string, target: Storage, root: boolean | undefined) {
  key = root ? key : BASE_KEY + key
  target.removeItem(key)
}

function clearStorage(target: Storage, root: boolean | undefined) {
  const length = target.length
  const clearList: string[] = []
  for (let i = 0; i < length; i++) {
    const key = target.key(i)
    if (key !== null) {
      if (root) {
        !key.startsWith(BASE_KEY) && clearList.push(key)
      } else {
        key.startsWith(BASE_KEY) && clearList.push(key)
      }
    }
  }
  clearList.forEach(key => {
    key && removeStorage(key, target, true)
  })
}

function getLocal(key: string, { root }: Options = {}) {
  return getStorage(key, localStorage, root)
}

function setLocal(key, value, { maxAge, root }: Options = {}) {
  return setStorage(key, value, maxAge, root, localStorage)
}

function getSession(key, { root }: Options = {}) {
  return getStorage(key, sessionStorage, root)
}

function setSession(key, value, { maxAge, root }: Options = {}) {
  return setStorage(key, value, maxAge, root, sessionStorage)
}

function removeLocal(key, { root }: Options = {}) {
  return removeStorage(key, localStorage, root)
}

function removeSession(key, { root }: Options = {}) {
  return removeStorage(key, sessionStorage, root)
}

function clearLocal({ root }: Options = {}) {
  return clearStorage(localStorage, root)
}

function clearSession({ root }: Options = {}) {
  return clearStorage(sessionStorage, root)
}

function setBaseKey(baseKey) {
  if (alreadySetKey) {
    console.error('@ycb/storage 重复设置 BASE_KEY!')
    return
  }
  BASE_KEY = baseKey
  alreadySetKey = true
}

export { getLocal, setLocal, getSession, setSession, removeLocal, removeSession, clearLocal, clearSession, setBaseKey }
