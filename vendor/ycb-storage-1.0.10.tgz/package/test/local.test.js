import { setBaseKey, getLocal, setLocal, removeLocal, clearLocal } from '../dist/storage.umd.min'
jest.useFakeTimers()

setBaseKey('TEST_')

// local
test('local 0', () => {
  setLocal('local-0', 0)
  expect(getLocal('local-0')).toBe(0)
})

test('local empty string', () => {
  setLocal('local-empty-string', '')
  expect(getLocal('local-empty-string')).toBe('')
})

test('local null', () => {
  setLocal('local-null', null)
  expect(getLocal('local-null')).toStrictEqual({})
})

test('local undefined', () => {
  setLocal('local-undefined', undefined)
  expect(getLocal('local-undefined')).toBe(undefined)
})

test('local true root falsy', () => {
  setLocal('local-true-root-falsy', true, {
    root: 0
  })
  expect(getLocal('local-true-root-falsy')).toBe(true)
  expect(
    getLocal('local-true-root-falsy', {
      root: 1
    })
  ).toBe(undefined)
})

test('local false root true', () => {
  setLocal('local-false-root-true', false, { root: true })
  expect(getLocal('local-false-root-true')).toBe(undefined)
  expect(getLocal('local-false-root-true', { root: true })).toBe(false)
})

test('local maxAge s', () => {
  setLocal(
    'local-maxAge-s',
    { a: 1, b: undefined },
    {
      maxAge: {
        s: 5
      }
    }
  )

  expect(getLocal('local-maxAge-s')).toStrictEqual({ a: 1 })
  jest.advanceTimersByTime(5001)
  expect(getLocal('local-maxAge-s')).toBe(undefined)
})

test('local maxAge all root truthy', () => {
  setLocal(
    'local-maxAge-all-root-truthy',
    { a: 1, b: '0.0' },
    {
      maxAge: {
        d: 1,
        h: 1,
        m: 1,
        s: 1
      },
      root: {}
    }
  )

  expect(getLocal('local-maxAge-all-root-truthy', { root: 0 })).toBe(undefined)
  expect(getLocal('local-maxAge-all-root-truthy', { root: {} })).toStrictEqual({ a: 1, b: '0.0' })
  jest.advanceTimersByTime(24 * 60 * 60 * 1000 + 60 * 60 * 1000 + 60 * 1000 + 1001)
  expect(getLocal('local-maxAge-all-root-truthy', { root: true })).toBe(undefined)
})

test('local remove', () => {
  setLocal('local-remove', 'remove')
  expect(getLocal('local-remove')).toBe('remove')
  removeLocal('local-remove')
  expect(getLocal('local-remove')).toBe(undefined)
})

test('local remove root', () => {
  setLocal('local-remove-root', 'remove')
  setLocal('local-remove-root', 'remove-root', { root: true })
  expect(getLocal('local-remove-root')).toBe('remove')
  expect(getLocal('local-remove-root', { root: true })).toBe('remove-root')
  removeLocal('local-remove-root')
  expect(getLocal('local-remove-root')).toBe(undefined)
  expect(getLocal('local-remove-root', { root: true })).toBe('remove-root')
  removeLocal('local-remove-root', { root: true })
  expect(getLocal('local-remove-root', { root: true })).toBe(undefined)
})

test('local clear', () => {
  setLocal('local-clear', 'clear')
  expect(getLocal('local-clear')).toBe('clear')
  clearLocal()
  expect(getLocal('local-clear')).toBe(undefined)
})

test('local clear root', () => {
  setLocal('local-clear-root', 'clear')
  setLocal('local-clear-root', 'clear-root', { root: true })
  expect(getLocal('local-clear-root')).toBe('clear')
  expect(getLocal('local-clear-root', { root: true })).toBe('clear-root')
  clearLocal()
  expect(getLocal('local-clear-root')).toBe(undefined)
  expect(getLocal('local-clear-root', { root: true })).toBe('clear-root')
  clearLocal({ root: true })
  expect(getLocal('local-clear-root')).toBe(undefined)
  expect(getLocal('local-clear-root', { root: true })).toBe(undefined)
})
