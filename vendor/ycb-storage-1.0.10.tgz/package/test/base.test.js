import { setBaseKey, setLocal, getLocal } from '../dist/storage.umd.min'

test('base key', () => {
  setBaseKey('KEY1_')
  setLocal('base-value1', 0)
  expect(getLocal('base-value1')).toBe(0)
})

test('base key2', () => {
  setBaseKey('KEY2_')
  setLocal('base-value2', true)
  expect(getLocal('base-value1')).toBe(0)
  expect(getLocal('base-value2')).toBe(true)
})
