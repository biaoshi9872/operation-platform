import { setBaseKey, getSession, setSession, removeSession, clearSession } from '../dist/storage.umd.min'
jest.useFakeTimers()

setBaseKey('TEST_')

// session
test('session 0', () => {
  setSession('session-0', 0)
  expect(getSession('session-0')).toBe(0)
})

test('session empty string', () => {
  setSession('session-empty-string', '')
  expect(getSession('session-empty-string')).toBe('')
})

test('session null', () => {
  setSession('session-null', null)
  expect(getSession('session-null')).toStrictEqual({})
})

test('session undefined', () => {
  setSession('session-undefined', undefined)
  expect(getSession('session-undefined')).toBe(undefined)
})

test('session true root falsy', () => {
  setSession('session-true-root-falsy', true, {
    root: 0
  })
  expect(getSession('session-true-root-falsy')).toBe(true)
  expect(
    getSession('session-true-root-falsy', {
      root: 1
    })
  ).toBe(undefined)
})

test('session false root true', () => {
  setSession('session-false-root-true', false, { root: true })
  expect(getSession('session-false-root-true')).toBe(undefined)
  expect(getSession('session-false-root-true', { root: true })).toBe(false)
})

test('session maxAge s', () => {
  setSession(
    'session-maxAge-s',
    { a: 1, b: undefined },
    {
      maxAge: {
        s: 5
      }
    }
  )

  expect(getSession('session-maxAge-s')).toStrictEqual({ a: 1 })
  jest.advanceTimersByTime(5001)
  expect(getSession('session-maxAge-s')).toBe(undefined)
})

test('session maxAge all root truthy', () => {
  setSession(
    'session-maxAge-all-root-truthy',
    { a: 1, b: '0.0' },
    {
      maxAge: {
        d: 1,
        h: 1,
        m: 1,
        s: 1
      },
      root: {}
    }
  )

  expect(getSession('session-maxAge-all-root-truthy', { root: 0 })).toBe(undefined)
  expect(getSession('session-maxAge-all-root-truthy', { root: {} })).toStrictEqual({ a: 1, b: '0.0' })
  jest.advanceTimersByTime(24 * 60 * 60 * 1000 + 60 * 60 * 1000 + 60 * 1000 + 1001)
  expect(getSession('session-maxAge-all-root-truthy', { root: true })).toBe(undefined)
})

test('session remove', () => {
  setSession('session-remove', 'remove')
  expect(getSession('session-remove')).toBe('remove')
  removeSession('session-remove')
  expect(getSession('session-remove')).toBe(undefined)
})

test('session remove root', () => {
  setSession('session-remove-root', 'remove')
  setSession('session-remove-root', 'remove-root', { root: true })
  expect(getSession('session-remove-root')).toBe('remove')
  expect(getSession('session-remove-root', { root: true })).toBe('remove-root')
  removeSession('session-remove-root')
  expect(getSession('session-remove-root')).toBe(undefined)
  expect(getSession('session-remove-root', { root: true })).toBe('remove-root')
  removeSession('session-remove-root', { root: true })
  expect(getSession('session-remove-root', { root: true })).toBe(undefined)
})

test('session clear', () => {
  setSession('session-clear', 'clear')
  expect(getSession('session-clear')).toBe('clear')
  clearSession()
  expect(getSession('session-clear')).toBe(undefined)
})

test('session clear root', () => {
  setSession('session-clear-root', 'clear')
  setSession('session-clear-root', 'clear-root', { root: true })
  expect(getSession('session-clear-root')).toBe('clear')
  expect(getSession('session-clear-root', { root: true })).toBe('clear-root')
  clearSession()
  expect(getSession('session-clear-root')).toBe(undefined)
  expect(getSession('session-clear-root', { root: true })).toBe('clear-root')
  clearSession({ root: true })
  expect(getSession('session-clear-root')).toBe(undefined)
  expect(getSession('session-clear-root', { root: true })).toBe(undefined)
})
