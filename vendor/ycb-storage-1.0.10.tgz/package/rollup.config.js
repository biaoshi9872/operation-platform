import pkg from "./package.json";
import NodeResolve from "@rollup/plugin-node-resolve";
import commonjs from "@rollup/plugin-commonjs";
import babel from "@rollup/plugin-babel";
import typescript from "rollup-plugin-typescript2";
import { terser } from "rollup-plugin-terser";

const name = "Storage";

export default {
  input: "src/index.ts",
  output: [
    {
      name,
      file: "dist/storage.umd.js",
      format: "umd",
    },
    {
      name,
      file: pkg.main,
      format: "umd",
      plugins: [terser()],
    },
    {
      name,
      file: "dist/storage.es.js",
      format: "es",
    },
    {
      name,
      file: pkg.module,
      format: "es",
      plugins: [terser()],
    },
  ],
  plugins: [
    NodeResolve(),
    commonjs(),
    typescript(),
    babel({
      babelHelpers: "bundled",
      exclude: "node_modules/**",
    }),
  ],
};
